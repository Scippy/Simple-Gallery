'------------------------------------------------------------------------------
' <generato automaticamente>
'     Codice generato da uno strumento.
'
'     Le modifiche a questo file possono causare un comportamento non corretto e verranno perse se
'     il codice viene rigenerato. 
' </generato automaticamente>
'------------------------------------------------------------------------------

Option Strict On
Option Explicit On

Namespace Ventrian.SimpleGallery

    Partial Public Class AddPhoto

        '''<summary>
        '''Controllo ucGalleryMenu.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents ucGalleryMenu As Global.Ventrian.SimpleGallery.Controls.GalleryMenu

        '''<summary>
        '''exifScripts control.
        '''</summary>
        '''<remarks>
        '''Auto-generated field.
        '''To modify move field declaration from designer file to code-behind file.
        '''</remarks>
        Protected WithEvents exifScripts As Global.System.Web.UI.WebControls.PlaceHolder

        '''<summary>
        '''Controllo exifScripts.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents exifScripts As Global.System.Web.UI.WebControls.PlaceHolder

        '''<summary>
        '''Controllo imgStep.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents imgStep As Global.System.Web.UI.WebControls.Image

        '''<summary>
        '''Controllo lblStep.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents lblStep As Global.System.Web.UI.WebControls.Label

        '''<summary>
        '''Controllo lblStepDescription.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents lblStepDescription As Global.System.Web.UI.WebControls.Label

        '''<summary>
        '''Controllo lblRequiresApproval.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents lblRequiresApproval As Global.System.Web.UI.WebControls.Label

        '''<summary>
        '''Controllo pnlStep1.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents pnlStep1 As Global.System.Web.UI.WebControls.Panel

        '''<summary>
        '''Controllo phStep1a.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents phStep1a As Global.System.Web.UI.WebControls.PlaceHolder

        '''<summary>
        '''Controllo rdoSelectExisting.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents rdoSelectExisting As Global.System.Web.UI.WebControls.RadioButton

        '''<summary>
        '''Controllo plAlbum.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents plAlbum As Global.System.Web.UI.UserControl

        '''<summary>
        '''Controllo drpAlbums.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents drpAlbums As Global.System.Web.UI.WebControls.DropDownList

        '''<summary>
        '''Controllo valSelectExisting.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents valSelectExisting As Global.System.Web.UI.WebControls.CustomValidator

        '''<summary>
        '''Controllo phStep1b.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents phStep1b As Global.System.Web.UI.WebControls.PlaceHolder

        '''<summary>
        '''Controllo rdoCreateNew.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents rdoCreateNew As Global.System.Web.UI.WebControls.RadioButton

        '''<summary>
        '''Controllo trParentAlbum.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents trParentAlbum As Global.System.Web.UI.HtmlControls.HtmlTableRow

        '''<summary>
        '''Controllo plParentAlbum.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents plParentAlbum As Global.System.Web.UI.UserControl

        '''<summary>
        '''Controllo drpParentAlbum.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents drpParentAlbum As Global.System.Web.UI.WebControls.DropDownList

        '''<summary>
        '''Controllo plCaption.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents plCaption As Global.System.Web.UI.UserControl

        '''<summary>
        '''Controllo txtCaption.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents txtCaption As Global.System.Web.UI.WebControls.TextBox

        '''<summary>
        '''Controllo valSelectNew.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents valSelectNew As Global.System.Web.UI.WebControls.CustomValidator

        '''<summary>
        '''Controllo plDescription.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents plDescription As Global.System.Web.UI.UserControl

        '''<summary>
        '''Controllo txtDescription.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents txtDescription As Global.System.Web.UI.WebControls.TextBox

        '''<summary>
        '''Controllo pnlStep2.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents pnlStep2 As Global.System.Web.UI.WebControls.Panel

        '''<summary>
        '''Controllo litBatchID.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents litBatchID As Global.System.Web.UI.WebControls.HiddenField

        '''<summary>
        '''Controllo fupFile.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents fupFile As Global.System.Web.UI.WebControls.FileUpload

        '''<summary>
        '''Controllo rexp.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents rexp As Global.System.Web.UI.WebControls.RegularExpressionValidator

        '''<summary>
        '''Controllo btnUploadFiles.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents btnUploadFiles As Global.System.Web.UI.WebControls.Button

        '''<summary>
        '''Controllo Button1.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents Button1 As Global.System.Web.UI.WebControls.Button

        '''<summary>
        '''Controllo Repeater1.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents Repeater1 As Global.System.Web.UI.WebControls.Repeater

        '''<summary>
        '''Controllo ucEditPhotos.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents ucEditPhotos As Global.Ventrian.SimpleGallery.Controls.EditPhotos

        '''<summary>
        '''Controllo pnlWizard.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents pnlWizard As Global.System.Web.UI.WebControls.Panel

        '''<summary>
        '''Controllo imgPrevious.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents imgPrevious As Global.System.Web.UI.WebControls.ImageButton

        '''<summary>
        '''Controllo cmdPrevious.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents cmdPrevious As Global.System.Web.UI.WebControls.LinkButton

        '''<summary>
        '''Controllo imgCancel.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents imgCancel As Global.System.Web.UI.WebControls.ImageButton

        '''<summary>
        '''Controllo cmdCancel.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents cmdCancel As Global.System.Web.UI.WebControls.LinkButton

        '''<summary>
        '''Controllo LinkButton1.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents LinkButton1 As Global.System.Web.UI.WebControls.LinkButton

        '''<summary>
        '''Controllo ImageButton1.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents ImageButton1 As Global.System.Web.UI.WebControls.ImageButton

        '''<summary>
        '''Controllo cmdNext2.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents cmdNext2 As Global.System.Web.UI.WebControls.Button

        '''<summary>
        '''Controllo cmdNext.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents cmdNext As Global.System.Web.UI.WebControls.LinkButton

        '''<summary>
        '''Controllo imgNext.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents imgNext As Global.System.Web.UI.WebControls.ImageButton

        '''<summary>
        '''Controllo pnlSave.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents pnlSave As Global.System.Web.UI.WebControls.Panel

        '''<summary>
        '''Controllo imgSave.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents imgSave As Global.System.Web.UI.WebControls.ImageButton

        '''<summary>
        '''Controllo cmdSave.
        '''</summary>
        '''<remarks>
        '''Campo generato automaticamente.
        '''Per la modifica, spostare la dichiarazione di campo dal file di progettazione al file code-behind.
        '''</remarks>
        Protected WithEvents cmdSave As Global.System.Web.UI.WebControls.LinkButton
    End Class
End Namespace
